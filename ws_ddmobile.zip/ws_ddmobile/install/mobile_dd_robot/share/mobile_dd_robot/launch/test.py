import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command, PathJoinSubstitution

from launch_ros.actions import Node
import xacro


def generate_launch_description():
    # Name and package
    robot_xacro_name = 'differential_drive_robot'
    name_package = 'mobile_dd_robot'

    # Paths
    pkg_share = get_package_share_directory(name_package)
    model_file = os.path.join(pkg_share, 'model', 'robot.xacro')
    world_file = os.path.join(pkg_share, 'model', 'empty_world.world')
    controllers_yaml = os.path.join(pkg_share, 'config', 'my_controllers.yaml')

    # Process xacro to get robot_description
    robot_description = xacro.process_file(model_file).toxml()

    # Launch Gazebo
    gazebo_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(get_package_share_directory('gazebo_ros'), 'launch', 'gazebo.launch.py')
        ),
        launch_arguments={'world': world_file}.items()
    )

    # Robot State Publisher
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{
            'robot_description': robot_description,
            'use_sim_time': True
        }]
    )

    # Spawn robot entity in Gazebo
    spawn_entity = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=['-topic', 'robot_description', '-entity', robot_xacro_name],
        output='screen'
    )

    # ROS 2 Control Node
    ros2_control_node = Node(
        package='controller_manager',
        executable='ros2_control_node',
        parameters=[{'robot_description': robot_description}, controllers_yaml],
        output='screen'
    )

    # Spawner Nodes
    joint_state_broadcaster_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['joint_state_broadcaster', '--controller-manager-timeout', '50'],
        output='screen'
    )

    diff_drive_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['diff_drive_controller', '--controller-manager-timeout', '50'],
        output='screen'
    )

    return LaunchDescription([
        gazebo_launch,
        robot_state_publisher,
        spawn_entity,
        ros2_control_node,
        joint_state_broadcaster_spawner,
        diff_drive_spawner
    ])

