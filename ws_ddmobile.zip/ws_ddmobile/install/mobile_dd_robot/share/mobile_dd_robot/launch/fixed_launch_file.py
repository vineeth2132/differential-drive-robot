import os
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from launch.substitutions import Command, PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():

    robotXacroName = 'differential_drive_robot'
    namePackage = 'mobile_dd_robot'
    modelFileRelativePath = 'model/robot.xacro'
    worldFileRelativePath = 'model/empty_world.world'

    pathModelFile = PathJoinSubstitution([
        FindPackageShare(namePackage),
        modelFileRelativePath
    ])

    pathWorldFile = PathJoinSubstitution([
        FindPackageShare(namePackage),
        worldFileRelativePath
    ])

    robot_description = ParameterValue(
        Command(['xacro ', pathModelFile]),
        value_type=str
    )

    gazeboLaunch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([
                FindPackageShare('gazebo_ros'),
                'launch',
                'gazebo.launch.py'
            ])
        ]),
        launch_arguments={'world': pathWorldFile}.items()
    )

    jointStatePublisherNode = Node(
        package='joint_state_publisher',
        executable='joint_state_publisher',
        name='joint_state_publisher',
        parameters=[{'use_sim_time': True}]
    )

    spawnModelNode = TimerAction(
        period=2.0,
        actions=[
            Node(
                package='gazebo_ros',
                executable='spawn_entity.py',
                arguments=['-topic', 'robot_description', '-entity', robotXacroName],
                output='screen'
            )
        ]
    )

    nodeRobotStatePublisher = TimerAction(
        period=4.0,
        actions=[
            Node(
                package='robot_state_publisher',
                executable='robot_state_publisher',
                output='screen',
                parameters=[{
                    'robot_description': robot_description,
                    'use_sim_time': True
                }]
            )
        ]
    )

    return LaunchDescription([
        gazeboLaunch,
        jointStatePublisherNode,
        spawnModelNode,
        nodeRobotStatePublisher
    ])

